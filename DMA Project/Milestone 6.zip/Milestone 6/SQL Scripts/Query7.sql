SELECT
    COUNT(Person_ID) AS count, status
FROM 
 patient info
GROUP BY status